#!/bin/bash
# 轻阅读后端更新脚本

echo "正在拉取最新镜像..."
docker-compose pull

echo "正在重启服务..."
docker-compose up -d

echo "更新完成！"
echo "查看日志：docker-compose logs -f"
