# 轻阅读后端部署教程

## 一键部署（Docker）

### 1. 安装 Docker

**Ubuntu/Debian:**
```bash
sudo apt-get update
sudo apt-get install docker.io docker-compose -y
```

**CentOS:**
```bash
sudo yum install docker -y
sudo systemctl start docker
sudo systemctl enable docker
```

### 2. 启动服务

```bash
# 进入部署目录
cd qread_backend

# 启动服务
docker-compose up -d

# 查看日志
docker-compose logs -f
```

### 3. 访问后台

- 后台地址：`http://你的服务器IP:8080`
- 默认账号：`admin`
- 默认密码：`adminadmin`

**首次登录后请立即修改密码！**

## 常用命令

```bash
# 启动
docker-compose up -d

# 停止
docker-compose down

# 重启
docker-compose restart

# 查看日志
docker-compose logs -f

# 更新镜像
docker-compose pull
docker-compose up -d
```

## 配置说明

编辑 `docker-compose.yml` 中的 environment 部分：

### 管理员账号
```yaml
ADMIN_USERNAME: admin      # 后台管理员账号
ADMIN_PASSWORD: adminadmin  # 后台管理员密码
```

### 用户权限
```yaml
USER_ALLOWCHANGE: "true"   # 是否允许自助修改权限
USER_ALLOWUPTXT: "false"   # 是否允许上传txt
USER_SOURCE: "0"            # 0:不允许修改书源, 1:允许后台修改, 2:独立书源
```

### 使用MySQL（可选）
```yaml
DB_TYPE: mysql
DB_JDBCURL: jdbc:mysql://127.0.0.1:3306/qread?characterEncoding=UTF-8&allowMultiQueries=true&serverTimezone=UTC
DB_USERNAME: root
DB_PASSWORD: your_password
```

### 使用代理（可选）
将 `JAVA_CMD` 改为：
```yaml
JAVA_CMD: java -Dhttp.proxyHost=127.0.0.1 -Dhttp.proxyPort=1080 -Dhttps.proxyHost=127.0.0.1 -Dhttps.proxyPort=1080 -jar /app/read.jar
```

## APP端配置

1. 打开轻阅读APP
2. 进入设置 → 服务器设置
3. 填写你的后端地址：`http://你的服务器IP:8080`
4. 注册账号并登录

## 注意事项

1. **防火墙**：确保服务器开放8080端口
2. **内存**：建议服务器内存2G以上
3. **WebSocket**：如使用反向代理（Nginx），请开启WebSocket支持
4. **HTTPS**：建议配置域名和SSL证书
5. **数据备份**：数据保存在 `./appdata` 目录，定期备份

## 常见问题

**Q: APP提示无法连接服务器？**
A: 检查防火墙是否开放8080端口，确认服务器IP正确。

**Q: 如何修改管理员密码？**
A: 编辑docker-compose.yml中的ADMIN_PASSWORD，然后重启服务。

**Q: 数据存在哪里？**
A: 所有数据保存在 `./appdata` 目录，包括数据库、配置、缓存等。
