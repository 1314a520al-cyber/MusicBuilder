#!/bin/bash
# 轻阅读后端停止脚本

echo "正在停止轻阅读后端..."
docker-compose down

echo "服务已停止"
