#!/bin/bash
# 轻阅读后端启动脚本

echo "正在启动轻阅读后端..."
docker-compose up -d

echo "等待服务启动..."
sleep 5

echo "服务状态："
docker-compose ps

echo ""
echo "后台地址：http://你的服务器IP:8080"
echo "默认账号：admin"
echo "默认密码：adminadmin"
echo ""
echo "查看日志：docker-compose logs -f"
